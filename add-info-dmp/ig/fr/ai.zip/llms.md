# ans.fhir.fr.pdsm4dmp#0.1.0: Utilisation de PDSm  dans le contexte d'EEDS(fr)

## Pages

* [Accueil](index.md)
* [Flux TD3.3a](transaction_td3.3a.md)
* [Flux TD3.3b](transaction_td3.3b.md)
* [Flux 02](transaction_2.md)
* [Téléchargements et usages](downloads.md)
* [Informations sur la traduction](translationinfo.md)
* [Autres Ressources](autres_ressources.md)
* [Exemples d'usages DMP](exemples_usage_dmp.md)
* [Flux TD3.3c](transaction_td3.3c.md)
* [Résumé des artefacts](artifacts.md)
* [Sécurité](securite.md)
* [Flux 01](transaction_1.md)
* [Flux TD3.3d](transaction_td3.3d.md)
* [Flux TD3.1a](transaction_td3.1a.md)
* [Historique des versions](change-log.md)
* [Flux TD3.1b](transaction_td3.1b.md)
* [Flux TD2](transaction_td2.md)
* [Flux TD3.2](transaction_td3.2.md)
* [Flux TD02](transaction_td02.md)
* [Vue d'ensemble](construction_des_flux.md)
* [Flux TD2.1](transaction_td2.1.md)
* [Specifications Techniques](specifications_techniques.md)

## Resources

### Logicals

* [ActorPS (LM)](StructureDefinition-ActorPS.md)
* [ActorPatient (LM)](StructureDefinition-ActorPatient.md)
* [ActorSNR (LM)](StructureDefinition-ActorSNR.md)
* [ActorSystem (LM)](StructureDefinition-ActorSystem.md)
* [ActorXDS (LM)](StructureDefinition-ActorXDS.md)
* [Author (LM)](StructureDefinition-Author.md)
* [AuthorDocumentEntry (LM)](StructureDefinition-AuthorDocumentEntry.md)
* [AuthorInstitution (LM)](StructureDefinition-AuthorInstitution.md)
* [AuthorSubmissionSet (LM)](StructureDefinition-AuthorSubmissionSet.md)
* [Document Entry (LM)](StructureDefinition-DocumentEntry.md)
* [EventCode (LM)](StructureDefinition-EventCode.md)
* [Folder (LM)](StructureDefinition-Folder.md)
* [Identifiant](StructureDefinition-Identifiant.md)
* [MatriculeINS](StructureDefinition-MatriculeINS.md)
* [PSIdNat](StructureDefinition-PSIdNat.md)
* [PatientId (LM)](StructureDefinition-PatientId.md)
* [SNR](StructureDefinition-SNR.md)
* [SourcePatientId (LM)](StructureDefinition-SourcePatientId.md)
* [SourcePatientInfo (LM)](StructureDefinition-SourcePatientInfo.md)
* [StructIdNat](StructureDefinition-StructIdNat.md)
* [SubmissionSet (LM)](StructureDefinition-SubmissionSet.md)

### Primitive-type Profiles

* [IdentifiantSysteme](StructureDefinition-IdentifiantSysteme.md)

### ConceptMaps

* [documentReferenceToPDSM](ConceptMap-documentReferenceToPDSM.md)
* [submissionSetToPDSM](ConceptMap-submissionSetToPDSM.md)

### ImplementationGuides

* [Utilisation de PDSm  dans le contexte d'EEDS](ImplementationGuide-ans.fhir.fr.pdsm4dmp.md)

### Examples

* [AuthorDispositif (Binary)](Binary-AuthorDispositif.md)
* [AuthorInstitutionCabinetRPPS (Binary)](Binary-AuthorInstitutionCabinetRPPS.md)
* [AuthorInstitutionSNR (Binary)](Binary-AuthorInstitutionSNR.md)
* [AuthorInstitutionStructure (Binary)](Binary-AuthorInstitutionStructure.md)
* [AuthorPSCabinetRPPS (Binary)](Binary-AuthorPSCabinetRPPS.md)
* [AuthorPatient (Binary)](Binary-AuthorPatient.md)
* [AuthorStructure (Binary)](Binary-AuthorStructure.md)
