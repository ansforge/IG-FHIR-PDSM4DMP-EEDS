# Specifications Techniques - Utilisation de PDSm dans le contexte d'EEDS v0.1.0

## Specifications Techniques

 
There is no translation page available for the current page, so it has been rendered in the default language 

