# ans.fhir.fr.pdsm4dmp#0.1.0: Utilisation de PDSm pour le DMP dans le contexte d'EEDS(en)

## Pages

* [Accueil](index.md)
* [Flux 02](transaction_2.md)
* [Téléchargements et usages](downloads.md)
* [Autres Ressources](autres_ressources.md)
* [Exemples d'usages DMP](exemples_usage_dmp.md)
* [Artifacts Summary](artifacts.md)
* [Sécurité](securite.md)
* [Flux 01](transaction_1.md)
* [Construction Des Flux](construction_des_flux.md)
* [Specifications Techniques](specifications_techniques.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### ImplementationGuides

* [Utilisation de PDSm pour le DMP dans le contexte d'EEDS](ImplementationGuide-ans.fhir.fr.pdsm4dmp.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
